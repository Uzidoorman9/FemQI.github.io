FemQi 1.12.2 scaffold
=====================

What this contains
- A complete GitHub Pages-ready `web/` folder with themed UI (pink/black).
- Gradle + TeaVM example configuration in `teavm/` to compile Java -> WebAssembly.
- Build helper scripts to place outputs into `web/`.
- Java template files (no Minecraft code) showing where to add overlays and QoL hooks.
- README and instructions. You must supply your unobfuscated 1.12.2 Java source. This scaffold does NOT include Minecraft code or assets.

Summary workflow
1. Place your unobfuscated 1.12.2 Java client sources inside `teavm/project/` following package layout.
2. Edit `teavm/project/build.gradle` and set `mainClass` to your Minecraft client entry point.
3. Run the Gradle wrapper: `./gradlew :teavm-project:teavmBuild` or `gradle build` if you prefer.
4. When build finishes the TeaVM output `femqi.wasm` and `femqi.js` will be copied into `web/` by the helper script.
5. Commit `web/` to GitHub and enable GitHub Pages in repository settings.

Notes on policy and legality
- This scaffold intentionally omits Minecraft proprietary code and assets to avoid copyright issues.
- You must only use assets and code you are licensed to use.
- Do not use the client to automate gameplay or violate servers' rules.

Files of interest
- web/               -> GitHub Pages static site
- teavm/             -> TeaVM Gradle project skeleton
- scripts/           -> helper scripts to copy build outputs and prepare deployable zip
- templates/java/    -> Java templates for client-side QoL overlays (examples only)

If you want, I will now build this scaffold into a zip you can download. After you run your TeaVM build locally and place `femqi.wasm` + `femqi.js` into `web/`, the site will work on GitHub Pages.
