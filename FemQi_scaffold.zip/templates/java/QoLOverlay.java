// Example template for a client-side overlay. Do NOT include Minecraft source here.
// Copy this class into your unobfuscated client project and call the methods from the game's render loop.
package com.femqi.client;

public class QoLOverlay {
    public static void renderOverlay() {
        // Called every frame from the client's render loop.
        // Implement FPS/ping display, crosshair customization, and simple client-side HUD here.
        // Ensure you do not perform network actions or automate input.

        // Example pseudocode:
        // int fps = FrameTracker.getFPS();
        // int ping = NetworkMonitor.getPing();
        // Renderer.drawText(10, 10, "FPS: " + fps);
        // Renderer.drawText(10, 24, "Ping: " + ping + " ms");
    }

    public static void onGuiOpen() {
        // Add UI toggles for features. Save settings client-side.
    }
}
